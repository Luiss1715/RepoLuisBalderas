#include <iostream>
#include <string>
#include<algorithm>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include "SortedLinkedList.h"
#include "Node.h"


using std::cout;
using std::cin;
using std::string;
using std::vector;
using std::ifstream;
using std::ofstream;
using std::vector;
using std::endl;


// Estructura para almacenar cada uno de los eventos de la bitacora
struct event {
  string fecha;
  string hora;
  string ipOrigen;
  string puertoOrigen;
  string dominioOrigen;
  string ipDestino;
  vector<int>ipDestinoInt;
  string puertoDestino;
  string dominioDestino;
};


// Imprimir event
std::ostream& operator<<(std::ostream &os, const event &e) {
  os << e.ipDestino << ",";
  os << e.fecha << ",";
  os << e.hora << ",";
  os << e.ipOrigen << ",";
  os << e.puertoOrigen << ",";
  os << e.dominioOrigen << ",";
  os << e.puertoDestino << ",";
  os << e.dominioDestino << std::endl;
  return os;
}

// Establecer como se compararan dos eventos
// Un evento e1 es menor a un evento e2, si la IP destino
// de e1 es menor a la IP destino de e2
// SortedLinkedList deberá usar este operador para determinar 
// posición en lista al insertar con 'add'
// Pueden optar por sobrecargar > en lugar de < o ambos
// dependiendo de su implementacición de SortedLinkedList
vector<int> SepararIP(const string &ip){
    //cout<<ip<<endl;
    vector<int>IpVector;
    std::istringstream ss(ip); 
    string ipTemp;
    while (std::getline(ss, ipTemp, '.')) { //separamos cada que haya un punto
        IpVector.push_back(std::stoi(ipTemp)); //pasamos de string a int 
    }
    return IpVector; 
}
bool operator<(event &e1, event &e2) {

   if (e1.ipDestinoInt.size() != 4 || e2.ipDestinoInt.size() != 4) {
        return false; // No son direcciones IP válidas
    }
    for(int i=0;i<4;i++){
    if(e1.ipDestinoInt.at(i)<=e2.ipDestinoInt.at(i)){  //si es menor o igual el primer numero
      return true;
    }
    else{ 
      return false;
    }
    }
    
  return false;
}

//PARA BUSQUEDA O(N/2) = O(N)
bool operator>(event &e1, event &e2) {
  // TODO: implementar este metodo
  vector<int> ip1 = SepararIP(e1.ipDestino);
  vector<int> ip2 = SepararIP(e2.ipDestino);

   if (ip1.size() != 4 || ip2.size() != 4) {
        return false; // No son direcciones IP válidas
    }
    for(int i=0;i<4;i++){
    if(ip1.at(i)>ip2.at(i)){  //si es menor o igual el primer numero
      return true;
    }
    else{ 
      return false;
    }
    }
    
  return false;
}

bool operator==(event &e1, event &e2) {
  if(e1.ipDestino==e2.ipDestino){
    return true;
  }
  return false;
}



void leer_archivo(SortedLinkedList<event>&SSL, string nombreArchivo) {
  ifstream archivo;
  archivo.open("equipo9.csv");
  string linea;
  char delimitador = ',';
  int contador{0};

  // Leemos todas las líneas
  while (getline(archivo, linea)) {
    //while(contador < 10000){
    //getline(archivo, linea);
    std::stringstream stream(linea); // Convertir la cadena a un stream
    string fecha, hora, ipOrigen, puertoOrigen, dominioOrigen, ipDestino,
        puertoDestino, dominioDestino;
    // Extraer todos los valores de esa fila
    getline(stream, fecha, delimitador);
    getline(stream, hora, delimitador);
    getline(stream, ipOrigen, delimitador);
    getline(stream, puertoOrigen, delimitador);
    getline(stream, dominioOrigen, delimitador);
    getline(stream, ipDestino, delimitador);
    getline(stream, puertoDestino, delimitador);
    getline(stream, dominioDestino, delimitador);

    //contador++;
    event evento1;
    // guardarlo en el vector
    for(int i=0;i<4;i++){
      evento1.ipDestinoInt.push_back(SepararIP(ipDestino).at(i));
    }
   
    evento1.fecha = fecha;
    evento1.hora = hora;
    evento1.ipOrigen = ipOrigen;
    evento1.puertoOrigen = puertoOrigen;
    evento1.dominioOrigen = dominioOrigen;
    evento1.ipDestino = ipDestino;
    evento1.puertoDestino = puertoDestino;
    evento1.dominioDestino = dominioDestino;

    // lo guardamos en el vector
    //eventos.push_back(evento1);
    SSL.add(evento1);
  }

  archivo.close();
}




void guardarArchivo(SortedLinkedList<event> &SSL, string nombreArchivo) {
  ofstream archivo(nombreArchivo);
 
  auto evento1 = SSL.begin();
  while(evento1!=SSL.end()){
    archivo << (*evento1).fecha << ",";
    archivo << (*evento1).hora << ",";
    archivo << (*evento1).ipOrigen << ",";
    archivo << (*evento1).puertoOrigen << ",";
    archivo << (*evento1).dominioOrigen << ",";
    archivo << (*evento1).ipDestino << ",";
    archivo << (*evento1).puertoDestino << ",";
    archivo << (*evento1).dominioDestino<<endl;
    evento1++;
  }
  archivo.close();
}

void ImprimirIP(string &ipDestino, SortedLinkedList<event>&SSL){
  //funcion lambda para saber si la ipDestino dada es igual a la actual
  auto IpPredicado = [&ipDestino](const event& e) { //recibe un parametro tipo event
      return (e.ipDestino == ipDestino); 
  };
  auto eventoImprimir = SSL.find(IpPredicado); //nos regresa un iterador
  auto actual = eventoImprimir; //eventoImprimir es un iterador, hacemos una copia
  while ((*actual).ipDestino == ipDestino) {  //mientras la IP sea igual a la ingresada
        // mostramos el evento con el operador << sobrecargado
        std::cout << "IpDestino: " << *actual << std::endl;
        actual++; //avanzamos un nodo
  }
}

int main() {
    // TODO: implementar este metodo
    // Crear una SortedLinkedList vacía
    vector<event> v{};
    SortedLinkedList<event> SSL;
    string ipDestino;
    // Leer archivo
    // Generar un struct de tipo event por cada linea
    // Agregar cada event a la SortedLinkedList
    leer_archivo(SSL, "equipo9.csv");
    
   
    // Al terminar de leer el archivo, la SLL contendrá todos los
    // eventos ordenados ascendentemente por IP destino
    // Guardar contenidos de la SLL en un archivo resultado
    guardarArchivo(SSL, "equipo9OrdenadoIP.csv");
  
    // Pedir al usuario una IP destino
    cout<<"Ingrese una IP Destino: ";
    cin>>ipDestino;
  
    // Generar una lambda que reciba un event y compare
    // su IP destino con la provista por el usuario
  
    // Obtener un apuntador al primer elemento con la misma
    // IP destino usando el método find
  
    // Imprimir en consola todos los eventos que corresponden 
    // a esa ip destino
    ImprimirIP(ipDestino,SSL);
}
