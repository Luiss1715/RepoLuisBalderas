#ifndef SortedLinkedList_H_INCLUDED
#define SortedLinkedList_H_INCLUDED
#include <iostream>
#include "Node.h"

using std::cout;
using std::endl;

// Forward declaration de la clase iterador
    // Necesaria para poder usarla al interior de SortedLinkedList
template <typename T>
class ListIterator;

template <typename T>
class SortedLinkedList
{
private:
    int list_size{};
    Node<T> *head{}; // Nodo centinela al inico de la lista
    Node<T> *bottom{}; // Nodo cenitnela al final de la lista

    // Declaramos a la clase iterador como amiga de esta clase
    // para que pueda hacer uso de sus miembros privados
    friend class ListIterator<T>;

public:
    // Asignamos el alias `iterator` a la clase ListIterator
    typedef ListIterator<T> iterator;

	// Constructor
    SortedLinkedList()
    {
        list_size = 0;
        head = new Node<T>{};
        bottom = new Node<T>{};
        head->next = bottom;
        head->prev = nullptr;
        bottom->prev = head;
        bottom->next = nullptr;
    } 
    
	// Imprime los elementos de la lista, 
    //separados por un salto de linea
    void print()
    {
        Node<T> *i = head->next;
        while( i != bottom)
        {
            cout << i->data << " ";
            cout << "\n";
            i = i->next;  
        }
    }
    
    // Agrega element en una posición determinada por el 
    // orden natural de los elementos
    // (determinado por el operador <)
    //NOS DIMOS CUENTA QUE AL QUERER INSERTAR MAS DE 5 MIL ELEMENTOS ORDENADOS
    //EN LA LISTA ES DEMASIADO LENTO(+ 1 MIN), POR LO QUE IMPLEMENTAMOS UNA BUSQUEDA BINARIA
    void add(T &element)
    {   
    
      //BUSQUEDA LINEAL
      Node<T> *i = head->next;
      //si la lista esta vacia no entra
      while( i!=bottom && i->data<element){//mientras no llegemos al final
        
        i = i->next;
        }
    
        auto newNode = new Node<T>{element};
        newNode->next = i;
        newNode->prev = i->prev;
        i->prev->next = newNode;
        i->prev = newNode;
        list_size++;



        //BUSQUEDA BINARIA
        
        /*Node<T> *left = head->next;
        Node<T> *right = bottom;
        bool leftBool{false};
        bool rightBool{false};

        while(left!=right && (left->data<element || right->data<element)){//mientas los pointers no esten hacia el mismo nodo
            //cout<<"entra";
            if(left->data == element || right->data == element){
                break;
            }
            if(left->data<element){ //si es menor left, lo avanzamos
                //cout<<"entra menor";
                left = left->next;
            }

            if(right->data>element){ //si right es mayor, vamos al prev
                //cout<<"entra mayor";
                right = right->prev;
            }

            if(left == bottom || left->data>element){ //para saber que ptr tiene la 
            //posicion a insertar
                leftBool = true;
            }
            else if(right==head || right->data<element){
                rightBool = true;
            }
        }

        if(leftBool){//insertamos entre left y un nodo anterior
            auto newNode = new Node<T>{element};
            newNode->next = left;
            newNode->prev = left->prev;
            left->prev->next = newNode;
            left->prev = newNode;
            list_size++;
        }

        if(rightBool){//insertamos entre rigth un nodo anterior
            auto newNode = new Node<T>{element};
            newNode->next = right->next;
            newNode->prev = right;
            right->next->prev = newNode;
            right->next = newNode;
            list_size++;
        } 

        if(!leftBool && !rightBool){//si esta vacia
            auto newNode = new Node<T>{element};
            newNode->next = left;
            newNode->prev = left->prev;
            left->prev->next = newNode;
            left->prev = newNode;
            list_size++;
        }*/
    }
   
  


    // Elimina el primer elemento de la lista 
    // La lista no debe de estar vacía
    T remove_first()
    {
        Node<T> *r = head->next;
        head->next = r->next;
        r->next->prev = head;
        --list_size;
        T removed{r->data};
        delete r;
        return removed;
    }
    
    // Regresa un iterador al primer nodo para el cual
    // el predicado fun evalue a verdadero
    // En caso de que ningun elemento evalue a verdadero
    // regresa un iterador a end
    template <typename F>
    iterator find(F &fun)
    {
        //fun es el predicado de una funcion lambda que recibe como parametro un event
        // TODO: Implementar este metodo
        auto actual = this->begin(); //empezamos al inicio
        while(actual != this->end()){ //mientras no lleguemos al final
            
            if(fun(*actual)){ //una funcion predicado, le mandamos como parametro
            //lo que queremos que evalue
                cout<<"entra"<<std::endl;
                return actual; //retornamos el iterador(puntero)
            }
           actual++;
        }
        return this->end();
   }
    
	// Elimina todos los elementos de la lista 
    void clear()
    {
        while(list_size > 0)
        {
            remove_first();
        }
    }

	// Regresa el tamaño de la lista 
    int get_size()
    {
        return list_size;
    }

	// Checa si la lista está vacia 
    bool is_empty()
    {
        return list_size == 0;
    }
    
    // Regresa un iterador al primer nodo de la lista
    // Si la lista está vacía, regresa end
    iterator begin()
    {
        return iterator{head->next};
    }

    // Regresa un iterador al elemento posterior
    // al final de la lista
    iterator end()
    {
        return iterator{bottom};
    }
        
	// Destructor
    ~SortedLinkedList()
    {
        clear();
        delete head;
        delete bottom;
    }  
};


// Clase iterador para SortedLinkedList
template <typename T>
class ListIterator
{
private:
    // Apuntador al nodo acutal del iterador
    // (nodo en el que se encuentra el iterador)
    Node<T> *current{};

public:
    // Constructor
    // (el nodo acutal es el nodo provisto como argumento)
    ListIterator(Node<T> *i)
    {
        current = i;
    }

    // Comparación de igualdad entre iteradores
    bool operator==(const ListIterator<T> &rhs) const
    {
        return current == rhs.current;
    }

    // Comparación de desigualdad entre iteradores
    bool operator!=(const ListIterator<T> &rhs) const
    {
        return current != rhs.current;
    }

    // Derreferenciador de iterador
    T& operator*()
    {
        return current->data;
    }

    // Operador ++iterador
    ListIterator& operator++()
    {
        current = current->next;
        return *this;
    }

    // Operador iterador++
    ListIterator operator++(int)
    {
        ListIterator<T> clone(this->current);
        current = current->next;
        return clone;
    }

    // Operador --iterador
    ListIterator& operator--()
    {
        current = current->prev;
        return *this;
    }

    // Operador iterador--
    ListIterator operator--(int)
    {
        ListIterator<T> clone(this->current);
        current = current->prev;
        return clone;
    }
};

#endif // DOUBLYLINKEDLIST_H_INCLUDED
