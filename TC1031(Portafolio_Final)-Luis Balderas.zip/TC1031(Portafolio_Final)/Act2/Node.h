#ifndef NODE_H_INCLUDED
#define NODE_H_INCLUDED
// Represents a node in a doubly linked list
template <typename T>
class Node
{
public:
    T data{};
    Node<T> *next{};
    Node<T> *prev{};

    // Constructs a new node containing a default value
    Node()
    {
        next = nullptr;
        prev = nullptr;
    }

    // Constructs a new node containing `data`
    Node(T data)
    {
        this->data = data;
        next = nullptr;
        prev = nullptr;
    }
};

#endif // NODE_H_INCLUDED