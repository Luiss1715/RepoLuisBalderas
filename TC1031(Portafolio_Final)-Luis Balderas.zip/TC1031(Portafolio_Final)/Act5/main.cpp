#include <iostream>
#include <ctime>
#include <unordered_map>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>


using std::cout;
using std::string;
using std::time_t;
using std::unordered_map;
using std::pair;
using std::string;
using std::vector;
using std::endl;

time_t make_time(int year, int month, int day, int hours, int minutes, int seconds) {
    time_t rawtime;
    time(&rawtime);
    struct tm *timeinfo = localtime(&rawtime);

    timeinfo->tm_year = year - 1900;
    timeinfo->tm_mon = month - 1;
    timeinfo->tm_mday = day;
    timeinfo->tm_hour = hours;
    timeinfo->tm_min = minutes;
    timeinfo->tm_sec = seconds;

    time_t dt = mktime(timeinfo);
    return dt;
}

vector<int> SepararFecha(const string &fecha){

    vector<int>fechaVector;
    std::istringstream ss(fecha); 
    string ipTemp;
    while (std::getline(ss, ipTemp, '-')) { //separamos cada que haya un punto
        fechaVector.push_back(std::stoi(ipTemp)); //pasamos de string a int  dia,mes,anio
    }
    return fechaVector; 
}

vector<int> SeperarHora(const string &hora){

    vector<int>horaVector;
    std::istringstream ss(hora); 
    string ipTemp;
    while (std::getline(ss, ipTemp, ':')) { //separamos cada que haya un punto
        horaVector.push_back(std::stoi(ipTemp)); //pasamos de string a int  hora, minutos, segundos
    }
    return horaVector; 
}



void leer_archivo(string nombreArchivo,unordered_map<string,pair<time_t,int>>&mapAccesosCercanos) {

  std::ifstream archivo;
  archivo.open(nombreArchivo);
  string linea;
  char delimitador = ',';


  // Leemos todas las líneas
  //int contador{0};
  while (getline(archivo, linea)) {

  //while(contador <= 10){
    //getline(archivo, linea);
    std::stringstream stream(linea); // Convertir la cadena a un stream
    string fecha, hora, ipOrigen, puertoOrigen, dominioOrigen, ipDestino,
        puertoDestino, dominioDestino;
    // Extraer todos los valores de esa fila
    getline(stream, fecha, delimitador);
    getline(stream, hora, delimitador);
    getline(stream, ipOrigen, delimitador);
    getline(stream, puertoOrigen, delimitador);
    getline(stream, dominioOrigen, delimitador);
    getline(stream, ipDestino, delimitador);
    getline(stream, puertoDestino, delimitador);
    getline(stream, dominioDestino, delimitador);



    //buscamos si ya existe ese dominio en el mapa
    if(mapAccesosCercanos.count(dominioDestino)){
      //cout<<"ya esta "<<dominioDestino<<endl;
      //comparamos con la otra fecha que ya se encuentra como value
      //obtenemos el acceso actual
      time_t t1 = make_time(SepararFecha(fecha).at(2), SepararFecha(fecha).at(1), SepararFecha(fecha).at(0), 
      SeperarHora(hora).at(0), SeperarHora(hora).at(1), SeperarHora(hora).at(2));
      //obtenemos el acceso mas reciente
      time_t t2 = mapAccesosCercanos.at(dominioDestino).first;
      int segundos = difftime(t1, t2);
        if(segundos<=30){ //actualizamos el contador y el acceso
          mapAccesosCercanos.at(dominioDestino).second++; //sumamos uno al contador
          mapAccesosCercanos.at(dominioDestino).first = t1; //actualizamos al acceso actual
          //cout<<"contador "<<mapAccesosCercanos.at(dominioDestino).second<<endl;

        }else{ //solamente actualizamos el acceso actual
           mapAccesosCercanos.at(dominioDestino).first = t1; //actualizamos al acceso actual
        }
    }

    else{ //lo insertamos en el map
      //cout<<"insertando "<<dominioDestino<<endl;
      time_t tiempo1 = make_time(SepararFecha(fecha).at(2), SepararFecha(fecha).at(1), SepararFecha(fecha).at(0), 
      SeperarHora(hora).at(0), SeperarHora(hora).at(1), SeperarHora(hora).at(2));

      //lo insertamos en el mapa
      mapAccesosCercanos[dominioDestino] =  std::make_pair(tiempo1, 0);
    }
    //contador++;
  }
  archivo.close();
}
int main() {
  // Ejemplo para calcular diferencia de segundos entre dos fechas

 

  //declaramos la tabla de hash
  unordered_map<string,pair<time_t,int>> mapAccesosCercanos; 

  leer_archivo("data/equipo9.csv", mapAccesosCercanos);
  //imprimimos el mapa


  cout<<mapAccesosCercanos.at("protonmail.com").second<<endl;


  //mostramos los top 5 de accesos cercanos

  // Copiamos los values del unordered_map a un vector 
  std::vector< pair<std::string, pair<time_t, int>>  > vectorAccesos(mapAccesosCercanos.begin(), mapAccesosCercanos.end());

  // Ordenamos el vector en orden descendente según el valor de second(contador) usando una funcion lambda
  //donde especificamos como comparar para ordenar
  std::sort(vectorAccesos.begin(), vectorAccesos.end(), [](const std::pair<std::string, std::pair<time_t, int>> &a,const std::pair<std::string, std::pair<time_t, int>> &b) {
      return a.second.second > b.second.second;
  });

  // Mostrar los 5 elementos con el valor second más grande
  std::cout << "Los 5 elementos con el valor second más grande:\n";
  //mostramos los 5 elementos con mayor accesos cercanos, usamos min por si hay más de 5 
  //elementos en todo el vector, entonces solo mostramos los primeros 5 
  for (int i = 0; i < std::min((int)vectorAccesos.size(),5); i++) {
      std::cout << "Dominio: " << vectorAccesos[i].first << ", Accesos cercanos: " << vectorAccesos[i].second.second << "\n";
  }

} 