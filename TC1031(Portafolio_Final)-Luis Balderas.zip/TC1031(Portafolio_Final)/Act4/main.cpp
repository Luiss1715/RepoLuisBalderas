#include <iostream>
#include <string> 
#include <fstream>
#include <iostream>
#include <istream>
#include <sstream>
#include "Digraph.h"

using std::string;
struct ip {
  string ipOrigen;
  string ipDestino;
};

void leer_archivo(Digraph<string> &direccionesIp, string nombreArchivo) {

  std::ifstream archivo;
  archivo.open(nombreArchivo);
  string linea;
  char delimitador = ',';


  // Leemos todas las líneas
  while (getline(archivo, linea)) {
    // while(contador < 10000){
    // getline(archivo, linea);
    std::stringstream stream(linea); // Convertir la cadena a un stream
    string fecha, hora, ipOrigen, puertoOrigen, dominioOrigen, ipDestino,
        puertoDestino, dominioDestino;
    // Extraer todos los valores de esa fila
    getline(stream, fecha, delimitador);
    getline(stream, hora, delimitador);
    getline(stream, ipOrigen, delimitador);
    getline(stream, puertoOrigen, delimitador);
    getline(stream, dominioOrigen, delimitador);
    getline(stream, ipDestino, delimitador);
    getline(stream, puertoDestino, delimitador);
    getline(stream, dominioDestino, delimitador);


    direccionesIp.add_edge(ipOrigen, ipDestino); //agregamos la conexion al grafo
    
  }

  archivo.close();
}
int main() {
  std::cout << "Hello World!\n";

  Digraph<string> direccionesIp;
  leer_archivo(direccionesIp, "equipo9OrdenadoIP.csv");

  //para encontrar cual es el nodo con mayor grado de salida, basta con encontrar el 
  //vector con mayor tamanio


  
 direccionesIp.MayorNodo();
    
}