#ifndef DIGRAPH_H_INCLUDED
#define DIGRAPH_H_INCLUDED

#include <iostream>
#include <vector>
#include <algorithm>

using std::vector;
using std::cout;

/**
* DiGraph implementation using an adjacency list
**/
template <typename T>
class Digraph
{
  private:
    // Vector of nodes' values
    vector<T> nodes{};

    // Vector of vectors containing each nodes' neighbors
    vector<vector<T>> adjacency{};

    // Returns the numeric index of a value
    // or -1 if value is not found
    int get_node_index(T node)
    {
        int i = 0;
        for(auto n : nodes)
        {
            if(node == n)
            {
                return i;
            }
            ++i;
        }
        return -1;
    }

  public:

    // Adds a new node to the Digraph if the value isn't 
    // in the DiGraph yet
    // Returns true if the insertion was made or false otherwise
    bool add_node(T node)
    {
        if(get_node_index(node) == -1) //si el nodo no existe en el grafo
        {
            nodes.push_back(node); //lo guardamos
            adjacency.push_back(vector<T>()); //le creamos su lista de adyacencia
            return true;
        }
        return false;
    }

    // Adds a new edge connecting src to dst
    // If either src or dst is not yet a node in the graph,
    // it adds it first
    void add_edge(T src, T dst)
    {
        int i = get_node_index(src); //obtenemos los indices donde estan los nodos
        int j = get_node_index(dst);
        if(i == -1) //si no existe, creamos el nodo
        {
            add_node(src); 
            i = nodes.size()-1; //sabemos que es el ultimo nodo anadido
        }
        if(j == -1) //si no existe, creamos el nodo
        {
            add_node(dst);
            j = nodes.size()-1;
        }
        if(std::find(adjacency[i].begin(), adjacency[i].end(), dst)==adjacency[i].end()){
            adjacency[i].push_back(dst);//si no esta, lo añadimos
          
          //buscamos en lista del primer arista, si no se encuentra ya el nodo que 
          //queremos añadir 

          
        }
        //si ya se encuentra, no lo anadimos
    }

    // Pretty print for the adjacency list 
    void print()
    {
        for(int i = 0; i < nodes.size(); ++i)
        {
            cout << nodes[i] << ": ";
            for(auto j : adjacency[i])
            {
                cout << j << " | ";
            }
            cout << "\n";
        }
    }

  void MayorNodo(){

    int mayor{0};
    int nodoMayor{0};
    for(int i = 0; i < nodes.size(); i++){
      //recordemos que adjecency[i] nos regresa un vector de conexiones del nodo actual
      if(adjacency[i].size()>mayor){ //si el tamanio del vector actual es mayor al propuesto
        mayor = adjacency[i].size(); //guardamos el grado de salida de ese nodo como el nuevo mayor
        nodoMayor = i; //guardamos el nodo mayor 
      }
    }
    cout<<"El nodo con mayor grado de salida es: "<<nodes[nodoMayor]<<std::endl;
    cout<<"Su grado de salida es de: "<<mayor<<std::endl;
  }
};

#endif