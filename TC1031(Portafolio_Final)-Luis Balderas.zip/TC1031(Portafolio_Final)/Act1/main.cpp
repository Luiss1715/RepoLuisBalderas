//Luis Balderas Sanchez A01751150
//Pablo Alonso Galvan A01748288
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using std::cin;
using std::cout;
using std::ifstream;
using std::ofstream;
using std::sort;
using std::string;
using std::vector;
using std::find_if;

// Estructura para almacenar cada uno de los eventos de la bitacora
struct event {
  string fecha;
  string hora;
  string ipOrigen;
  string puertoOrigen;
  string dominioOrigen;
  string ipDestino;
  string puertoDestino;
  string dominioDestino;
};

// Sobrecarga de operador <<
// Sirve para poder imprimir event
// os es una referencia a un output stream (tipicamente cout)
std::ostream &operator<<(std::ostream &os, const event &e) {
  os << e.fecha << ",";
  os << e.hora << ",";
  os << e.ipOrigen << ",";
  os << e.puertoOrigen << ",";
  os << e.dominioOrigen << ",";
  os << e.ipDestino << ",";
  os << e.puertoDestino << ",";
  os << e.dominioDestino << std::endl;
  return os;
}

// Establecer como se compararan dos eventos
// Importante pues determinara como se hara el sort
bool operator<(const event &e1, const event &e2) {

  // comparar e1 su fecha y su hora y si ambas son menores

  // si la fecha es menor
  if (e1.fecha < e2.fecha) {
    return true;
  }

  // si la fecha es igual
  else if (e1.fecha == e2.fecha) {
    if (e1.hora <= e2.hora) {
      return true;
    }

    else {
      return false;
    }
  }
  return false;
}

void leer_archivo(vector<event> &eventos, string nombreArchivo) {

  ifstream archivo;
  archivo.open("data/equipo9.csv");
  string linea;
  char delimitador = ',';

  // Leemos todas las líneas
  while (getline(archivo, linea)) {
    std::stringstream stream(linea); // Convertir la cadena a un stream
    string fecha, hora, ipOrigen, puertoOrigen, dominioOrigen, ipDestino,
        puertoDestino, dominioDestino;
    // Extraer todos los valores de esa fila
    getline(stream, fecha, delimitador);
    getline(stream, hora, delimitador);
    getline(stream, ipOrigen, delimitador);
    getline(stream, puertoOrigen, delimitador);
    getline(stream, dominioOrigen, delimitador);
    getline(stream, ipDestino, delimitador);
    getline(stream, puertoDestino, delimitador);
    getline(stream, dominioDestino, delimitador);

    event evento1;
    // guardarlo en el vector
    evento1.fecha = fecha;
    evento1.hora = hora;
    evento1.ipOrigen = ipOrigen;
    evento1.puertoOrigen = puertoOrigen;
    evento1.dominioOrigen = dominioOrigen;
    evento1.ipDestino = ipDestino;
    evento1.puertoDestino = puertoDestino;
    evento1.dominioDestino = dominioDestino;

    // lo guardamos en el vector
    eventos.push_back(evento1);
  }

  archivo.close();
}

void guardarArchivo(vector<event> v, string nombreArchivo) {

  ofstream archivo(nombreArchivo);
  for (auto evento1 : v) {
    archivo << evento1.fecha << ",";
    archivo << evento1.hora << ",";
    archivo << evento1.ipOrigen << ",";
    archivo << evento1.puertoOrigen << ",";
    archivo << evento1.dominioOrigen << ",";
    archivo << evento1.ipDestino << ",";
    archivo << evento1.puertoDestino << ",";
    archivo << evento1.dominioDestino;
  }

  archivo.close();
}



void ImprimirEventos(std::vector<event>& v, const std::string& fechaInclusiva, const std::string& fechaExclusiva) {
    
  //funcion lambda para saber si la fecha esta en el rango
    // y accedemos a fechaInclusiva y fechaExclusiva por referencia
  auto fechaPredicado = [&fechaInclusiva, &fechaExclusiva](const event& e) {
        return (e.fecha >= fechaInclusiva && e.fecha < fechaExclusiva);
    };

    auto eventoImprimir = std::find_if(v.begin(), v.end(), fechaPredicado); 

    while (eventoImprimir != v.end()) {
        // mostramos el evento con el operador << sobrecargado
        std::cout << "Fecha: " << *eventoImprimir << std::endl;

        // Encuentra el próximo evento que esta en el rango de fechas
        eventoImprimir = std::find_if(std::next(eventoImprimir), v.end(), fechaPredicado);
    }
}
int main() {

  vector<event> v{};
  event evento2;
  string fechaInclusiva;
  string fechaExclusiva;

  // Leer archivo
  // Guardar archivo como vector de eventos (usa v.push_back para agregar
  // elementos al final del vector)
  leer_archivo(v, "equipo9.csv");

  // Ordernar vector usando sort
  std::sort(v.begin(), v.end());

  // Guardar vector ordenado a archivo resultado
  guardarArchivo(v, "data/tequipo9Ordenado.csv");

  // Pedir al usuario fecha de inico y fin
  cout << "Ingresa la fecha de inicio en formato dd-m-yyyy: ";
  cin >> fechaInclusiva;
  cout << "Ingresa la fecha final en formato dd-m-yyyy: ";
  cin >> fechaExclusiva;

  // Imprimir a consola todos los eventos entre inicio y fin (usar find e
  // iteradores)
  ImprimirEventos(v, fechaInclusiva,fechaExclusiva);
  

  return 0;
}