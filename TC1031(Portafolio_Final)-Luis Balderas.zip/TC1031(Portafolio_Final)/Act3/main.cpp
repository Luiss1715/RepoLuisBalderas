#include <fstream>
#include <iostream>
#include <istream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

using std::string;

// creamos struct
struct ip {
  int n_accesos;
  string ip;
};

// 1 y 2. COMPLEJIDAD O(N)
void leer_archivo(std::vector<ip> &direccionesIp, string nombreArchivo) {

  std::ifstream archivo;
  archivo.open(nombreArchivo);
  string linea;
  char delimitador = ',';
  string ipTemp = "";
  int contadorIp{0};
  ip ip;

  // Leemos todas las líneas
  while (getline(archivo, linea)) {
    // while(contador < 10000){
    // getline(archivo, linea);
    std::stringstream stream(linea); // Convertir la cadena a un stream
    string fecha, hora, ipOrigen, puertoOrigen, dominioOrigen, ipDestino,
        puertoDestino, dominioDestino;
    // Extraer todos los valores de esa fila
    getline(stream, fecha, delimitador);
    getline(stream, hora, delimitador);
    getline(stream, ipOrigen, delimitador);
    getline(stream, puertoOrigen, delimitador);
    getline(stream, dominioOrigen, delimitador);
    getline(stream, ipDestino, delimitador);
    getline(stream, puertoDestino, delimitador);
    getline(stream, dominioDestino, delimitador);

    
    if (ipDestino == ipTemp) { // si es la misma a la ultima ip leida
      contadorIp++;
      
    }

    else if(ipTemp != "" && ipDestino != ipTemp ){ // si no es la misma y no es la primera ip leida
      ip.n_accesos = contadorIp;
      ip.ip = ipTemp;
      direccionesIp.push_back(ip);

      contadorIp = 1; // reiniciamos contador

      ipTemp = ipDestino; // guardamos la ip nueva

     
    }
    else{ //solo entrara en la primera ip leida 
    contadorIp++;
    ipTemp = ipDestino; // guardamos la ultima IP leida en ipTemp
    }
  }

  archivo.close();
}

//3 convertir a heap
bool operator<(ip &ip1, ip &ip2) {
   return ip1.n_accesos < ip2.n_accesos;
}


int main() {
  std::cout << "Hello World!\n";

  std::vector<ip> direccionesIP;
  int n{0};

  // 1. abrir archivo con ip ordenadas
  // 2. contar cuantas veces se repite la ip y guardar en un vector
  leer_archivo(direccionesIP, "equipo9OrdenadoIP.csv");

  /*ESTO SOLO ES PARA COMPROBAR QUE EL HEAP FUNCIONA BIEN
  std::sort(direccionesIP.begin(),direccionesIP.end());
  std::vector<ip>vectorIp = direccionesIP;
  std::cout<<"tamanio: "<<vectorIp.size()-1<<std::endl;*/
  
  
  // 3. convertir a heap (make heap) entre mas accesos
  std::make_heap(direccionesIP.begin(), direccionesIP.end()); //COMPLEJIDAD O(N)

  
  // 4. pedir al usuario un valor n y desplegar las n ip
  std::cout<<"Ingresa el numero de IPs que quieres ver: ";
  std::cin>>n;

  for(int i{0}; i<n; i++){ //COMPLEJIDAD O(N)
  // con mayor acceso (pop heap)
  //std::cout<<"IP: "<<vectorIp[vectorIp.size()-(i+1)].ip<<std::endl;
  //std::cout<<"NUMERO DE VECES: "<<vectorIp[vectorIp.size()-(i+1)].n_accesos<<std::endl;
  //COMPLEJIDAD O(LOGN)
  std::pop_heap(direccionesIP.begin(), direccionesIP.end()); //mandamos al final
  
  std::cout<<"IP "<<i+1<<": "<<direccionesIP.back().ip<<std::endl<<std::endl; //obtenemos el elemento mas grande que ya lo recorrimos al final
    direccionesIP.pop_back(); // lo eliminamos del vector 
  }
  
  return 0;
}
  