


#include "cliente_prueba.h"



using namespace std;


class ArrClientes{
int capacidad_clientes = 10;
//Atributos
Cliente **arreglo;  //USAMOS DOBLE PUNTERO PARA QUE EL PRIMER PUNTERO APUNTE AL OBJETO Y EL SEGUNDO PUNTERO APUNTE AL ARREGLO
int indice;



public:
ArrClientes(){
    arreglo = new Cliente*[capacidad_clientes];//Arreglo de clientes
    indice = -1; //en -1 para que al agregar el primer cliente al arreglo ocupe la posici�n "0"
}

~ArrClientes(){}//Destructor

void RegistrarCliente(Cliente *cliente)
    {
    indice++;
    arreglo[indice] = cliente;
    }

void EliminarCliente(){
    for(int i =0 ; i<indice;i++)
        {
        arreglo[i] = arreglo[i+1];//recorremos los valores a la izquierda
        }
    indice--;
}


//Get_Cliente
Cliente *Get_Cliente(int pos){
return arreglo[pos];//devolvemos el cliente solicitado
}

//Get_CapacidadClientes
int Get_Capacidad_Clientes(){
return capacidad_clientes;
}


//indice
int Get_Indice()
{
  return indice;
}


};

