
using namespace std;
class Aerolineas {
string nombre;
//Vuelo vuelo;//composicion

//PREGUNTAR COMO HACER QUE SE CREE EL VUELO AQUI CON LOS PARAMETROS DE VUELO
public:

Aerolineas(){
//constructor vacio
}

~Aerolineas(){
  cout<<"Destruyendo aerolinea"<<endl;
}


void SetNombre(string nombrep){
nombre = nombrep;
}

string GetNombre(){
return nombre;
}


/*void SetNumero_aviones(int num){
numero_aviones = num;
}

int GetNumeroAviones(){
return numero_aviones;
}*/




Aerolineas(string nombrep){
    cout<<"Creando arl"<<endl;
  nombre = nombrep;
}




public:


};
