#include"vuelo.h"
#include<windows.h>
#include <stdlib.h>
#include <time.h>
using namespace std;


//Clase cliente
class Cliente {

//atributos
string numero_vuelo;
float precio;
int duracion_viaje_min;
float km_recorridos;
string nombre;
string destino;
string contrasenia;
int edad;
int boletosReservados;
Vuelo *vuelo; //Asociaci�n1




public:


Cliente(){//constructor vacio

}
Cliente (string nombrep,int edadp,string contraseniap){
    nombre = nombrep;
    edad = edadp;
    contrasenia = contraseniap;
    destino = "NO ASIGNADO";
    precio = 0;
    km_recorridos = 0;
  }

~Cliente (){}//destructor

    // Set boletos reservados
void SetBoletosReservados(int boletosReservadosp){
        boletosReservados = boletosReservadosp;
}
    // get boletos reservados
    int GetBoletosReservados(){
        return boletosReservados;
    }

//SetVuelo
void SetVuelo(Vuelo *vuelop){
vuelo = vuelop;
}

//GetVuelo
Vuelo *Get_Vuelo(){
return vuelo;//obtenemos el objeto Vuelo
}

//vuelo
void Set_Numero_Vuelo(string numero_vuelop){
numero_vuelo = numero_vuelop;
}
string Get_Numero_Vuelo()
{
  return numero_vuelo;
}

//destino
string Get_Destino(){
return destino;}

void Set_Destino(string destinop){
destino = destinop;
}

//precio
void Set_Precio (float preciop){
 precio = preciop;
}
float Get_Precio()
{
  return precio;
}

//contrase�a
void Set_contrasenia(string contraseniap){
contrasenia = contraseniap;
}

string Get_Contrasenia(){
return contrasenia;}

//duracion_viaje_min
void Set_Duracion_Viaje(int duracion_viajep){
duracion_viaje_min=duracion_viajep;
}
int GetDuracionVuelo()
{
  return duracion_viaje_min;
}

// kilometros recorridos
void Set_Distancia (float distanciap){
km_recorridos = distanciap;
}
float Get_KM_Recorridos()
{
  return km_recorridos;
}


//Nombre
void SetNombre(string nombrep){
  nombre = nombrep;
}
string GetNombre(){
  return nombre;
}

//Edad
void SetEdad(int edadp){
  edad = edadp;
}
int GetEdad(){
  return edad;
}

//Otros m�todos
/*
void Agregar_lista_de_espera(Vuelo *vuelo){
vuelo->SetEspera(Cliente);
cout<<"Agregado con exito a la lista de espera"<<endl;
}*/




void Reservar_Vuelo(Vuelo *vuelop, int numBoletos){
boletosReservados = numBoletos;
cout<<"Reservando vuelo.";
sleep(1);//segundos a esperar
cout<<".";
sleep(1);
cout<<".";
sleep(1);
vuelo = vuelop;
numero_vuelo = (vuelo->Get_Numero_Vuelo()); //guardamos el numero del vuelo para el cliente
precio = (vuelo->GetPrecio()) * (float)numBoletos;
duracion_viaje_min = vuelo->GetDuracionVuelo();
km_recorridos += vuelo->GetDistancia();
destino = vuelo->GetDestino();
vuelo->SetDisponibilidad((int)vuelo->GetDisponibilidad()-numBoletos);
//como usamos puntero, el vuelo del parametro se modifica desde el main, no es necesario un return


/*if(vuelo->GetDisponibilidad == 0){
Agregar_lista_de_espera(vuelo);
}*/

system("cls");
cout<<endl<<"Reservacion exitosa"<<endl<<endl;


cout<<"Numero De Vuelo: "<<numero_vuelo<<endl;
cout<<"Duracion estimada de vuelo: "<<duracion_viaje_min<< " minutos"<<endl;
cout<<"precio del boleto: "<<precio<<"$"<<endl;
cout<<"kilometros acumulados finales: "<<km_recorridos<<" km"<<endl;
}

string Cancelar_Reservacion(){

string num_vuelo;

cout<<"Cancelando Reservacion.";
sleep(1);//segundos a esperar
cout<<".";
sleep(1);
cout<<".";
sleep(1);


num_vuelo = Get_Vuelo()->Get_Numero_Vuelo();//guardamos el vuelo el cual vamos a cancelar la reservacion
//vuelop->SetDisponibilidad(vuelop->GetDisponibilidad()+1);
numero_vuelo = "";
precio = 0;
duracion_viaje_min = 0;
destino = "NO ASIGNADO";
boletosReservados = 0;
km_recorridos = km_recorridos - Get_Vuelo()->GetDistancia();
//vuelo->SetDisponibilidad(vuelo->GetDisponibilidad()+1); SI FUNCIONA, PEROOOO ACTUALIZA EL OBJETO ORIGINAL. NO ACTUALIZA EL ARRAY



SetVuelo(NULL);//le asignamos un objeto vuelo vac�o al cliente

return num_vuelo;
}


void MostrarDatos(){
cout<<endl<<"Datos del cliente: "<<endl;
cout<<"Numero de vuelo:" <<numero_vuelo<<endl;
cout<<"Precio: "<<"$"<<precio<<endl;
cout<<"Duracion de vuelo: " <<duracion_viaje_min<<endl;
cout<<"Distancia recorrida: " <<km_recorridos<<endl;
cout<<"Nombre: "<<nombre<<endl;
cout<<"edad: "<<edad<<endl;
}
};
