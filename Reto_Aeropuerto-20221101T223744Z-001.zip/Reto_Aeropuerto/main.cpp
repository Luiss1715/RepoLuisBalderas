#include <iostream>
#include<windows.h>//para usar sleep()
#include<unistd.h>//para usar sleep()
#include"ArrClientes.h"

using namespace std;



//falta incluir lo de los archivos txt
//falta hacer que un cliente pueda reservar mas de 1 asiento y por consecuencia mostrar el precio de los boletos adquiridos


int main() {
bool cliente_encontrado = false;
bool cliente_registrado = false;
bool vuelos_encontrados = false;
bool vuelo_seleccionado_encontrado = false;
bool reservacion_confirmada = false;
bool asiento_disponible = false;
bool num_vuelo_valido = false;

bool cliente_encontrado_cancelar_reservacion = false;

int menu=0;

string fecha;
string destino;
string numero_vuelo;
string num_vuelo_escogido = "0";
string vuelo_cancelado;
char confirmar_vuelo;
string nombre_cliente;
int edad;
char repetir;
int numBoletos;

string nombre_case1;
string contrasenia_case1;
string password;
int edad_case_1;


//variables cliente
int indice_cliente;



Aerolineas arl1("Aeromexico");
Aerolineas arl2("VivaAerobus");
Aerolineas arl3("Volaris");
Aerolineas arl4("MagniCharters");
Aerolineas arl5("Interjet");

/*Aerolineas arl1();
Aerolineas arl2();
Aerolineas arl3();
Aerolineas arl4();
Aerolineas arl5();*/

//(fecha,numero_vuelo,precio,duracion_viaje(minutos),capacidad,distancia,Aerolinea arl, destino)
Vuelo vuelo1("21/07/2022","756",7230,360,1,78985.4,arl1,"Monterrey");
Vuelo vuelo2("21/07/2022","757",4343,440,3,39213.2,arl2,"Cancun");
Vuelo vuelo3("22/07/2022","758",17420,764,420,328213.2,arl3,"Merida");
Vuelo vuelo4("23/07/2022","759",21897,109,523,32892.4,arl4,"Ciudad de Mexico");
Vuelo vuelo5("24/07/2022","760",21897,109,523,32892.4,arl5,"Guadalajara");
Vuelo vuelo_seleccionado;


/*vuelo1.arl.SetNombre("Aeromexico");
vuelo2.arl.SetNombre("VivaAerobus");
vuelo3.arl.SetNombre("Volaris");
vuelo4.arl.SetNombre("MagniCharters");
vuelo5.arl.SetNombre("Interjet");*/

Vuelo arreglo_vuelos [5]= {vuelo1, vuelo2, vuelo3, vuelo4, vuelo5};




ArrClientes *obj_Arr_Cliente = new ArrClientes();//creamos el ArrCliente (LO CREAMOS DE FORMA DIN�MICA) SOLO CREAMOS UN OBJETO ArrCliente PARA PODER ACCEDER AL M�TODO DE AGREGAR_CLIENTES
Cliente *nuevoCliente; //creamos un objeto cliente
Cliente *cliente_seleccionado;






do{
//reseteamos las banderas
cliente_encontrado = false;
cliente_registrado = false;
vuelos_encontrados = false;
vuelo_seleccionado_encontrado = false;
reservacion_confirmada = false;
asiento_disponible = false;
num_vuelo_valido = false;

cliente_encontrado_cancelar_reservacion = false;





system("cls");
cout<<"(1) Registrar clientes"<<endl;
cout<<"(2) Buscar Vuelos Por Fecha"<<endl;
cout<<"(3) Buscar Vuelos Por Destino"<<endl;
cout<<"(4) Visualizar Clientes"<<endl;
cout<<"(5) Cancelar reservacion"<<endl;
cout<<"(6) Salir"<<endl;
cin>>menu;


switch (menu){
    case 1:{ //ESTE YA ESTA LISTO
    system("cls");


    if(obj_Arr_Cliente->Get_Indice() == obj_Arr_Cliente->Get_Capacidad_Clientes()){ //si el indice en el que va el arreglo es igual a la capacidad, entonces ya no agregamos
        cout<<"YA NO SE PUEDEN REGISTRAR MAS CLIENTES"<<endl;
        break;
    }

    else{
    cliente_registrado = false;
    cout<<"\t\t\t\t\t\tREGISTRO DE CLIENTES"<<endl<<endl;
    cout<<"Ingresa el nombre: ";
    fflush(stdin);//limpiamos la memoria cach� de entrada
    getline(cin,nombre_case1);
    cout<<"Ingresa la edad: ";
    cin>>edad_case_1;
    cout<<"Password: ";
    cin>>contrasenia_case1;

    for (int i=0;i<=obj_Arr_Cliente->Get_Indice();i++){//si el cliente ya existe
        if(nombre_case1==obj_Arr_Cliente->Get_Cliente(i)->GetNombre()){// si el usuario ya existe
                cliente_registrado = true;
                cout<<"ESTE USUARIO YA SE ENCUENTRA REGISTRADO"<<endl;
                break;
        }

    }
    if(!cliente_registrado){ // si el cliente no se encuentra registrado CLIENTE_REGISTRADO == false
    nuevoCliente = new Cliente(nombre_case1,edad_case_1,contrasenia_case1);//creamos al cliente
    obj_Arr_Cliente->RegistrarCliente(nuevoCliente);//lo agregamos al arreglo de clientes
    }
    }
    break;
    }




case 2:{
    system("cls");
    cout<<endl<<"Ingresa la fecha en la que desee buscar vuelos: ";
    cin>>fecha;
    system("cls");

    for (int i = 0; i < 5; i++){
        if(fecha==arreglo_vuelos[i].GetFecha()){//mostramos los vuelos disponibles en la fecha ingresada (SE MUESTRAN REPETIDOS, NO ENTIENDO PQ)
            arreglo_vuelos[i].MostrarVuelos();
            vuelos_encontrados = true;
        }
    }






if(vuelos_encontrados == false)//si no hay vuelos disponibles
{
    cout<<"NO HAY VUELOS DISPONIBLES PARA LA FECHA INGRESADA"<<endl;
    break;
}



else if(vuelos_encontrados == true){
    cout<<"Ingresa el numero de vuelo que deseas: ";
    cin>>numero_vuelo;//pedimos el numero



    for (int i = 0; i < 5; i++){//verificamos que el vuelo seleccionado exista
            if(numero_vuelo == arreglo_vuelos[i].Get_Numero_Vuelo()){//si el numero de vuelo escogido si esta disponible
                vuelo_seleccionado_encontrado = true;
                vuelo_seleccionado = arreglo_vuelos[i];
                num_vuelo_valido = true;
            }
    }

    if(!num_vuelo_valido){ //si vuelo_valido == false
        cout<<"NUMERO DE VUELO INVALIDO"<<endl;
        break;
    }
    cout << "Ingresa el numero de boletos que desea reservar: ";
    cin >> numBoletos;
    system("cls");



if(vuelo_seleccionado.GetDisponibilidad()>=numBoletos){//si aun hay asientos disponibles
            asiento_disponible = true;
            }


    if(!asiento_disponible){
        cout<<"EL VUELO YA NO CUENTA CON ASIENTOS DISPONIBLES"<<endl;
        break;
    }

    if(vuelo_seleccionado_encontrado && asiento_disponible){//si si existe el vuelo seleccionado

        vuelo_seleccionado.MostrarDatos();//mostramos los datos del vuelo para confirmar
        cout<<"Por favor ingresa \"S\" si confirmas tu vuelo o \"N\" si deseas regresar al menu: ";
        fflush(stdin);
        cin>>confirmar_vuelo;

                if(confirmar_vuelo =='S'){//confirmamos la reservacion del vuelo
                        reservacion_confirmada = true;
                        system("cls");
                        fflush(stdin);
                        cout<<endl<<"Usuario: ";
                        getline(cin,nombre_cliente);
                        cout<<endl<<"Password: ";
                        cin>>password;
                }//fin if de confirmar vuelo
                else{
                    break;
                }
    }
}



if(reservacion_confirmada == true){//reservar vuelo para cliente

    //BUSCAMOS SI EL CLIENTE YA ESTA REGISTRADO
    for(int i =0; i<=obj_Arr_Cliente->Get_Indice();i++)//recorremos todo el arreglo de los clientes
    {
        if(nombre_cliente==obj_Arr_Cliente->Get_Cliente(i)->GetNombre() && password == obj_Arr_Cliente->Get_Cliente(i)->Get_Contrasenia() ){// si el usuario ya existe autorizamos el siguiente paso
        cliente_encontrado = true;
        indice_cliente = obj_Arr_Cliente->Get_Indice();//obtenemos el cliente
        cliente_seleccionado = obj_Arr_Cliente->Get_Cliente(i);
        }
    }

    if(cliente_encontrado == true){//realizamos la reservaci�n
        cliente_seleccionado->Reservar_Vuelo(&vuelo_seleccionado, numBoletos);
        //una vez que hemos hecho la reservacion, hay que actualizar los datos del vuelo en el array (vuelo_seleccionado ya tiene la update de las modificaciones hechas)
        for (int i = 0; i < 5; i++){//verificamos que el vuelo seleccionado exista
            if(vuelo_seleccionado.Get_Numero_Vuelo() == arreglo_vuelos[i].Get_Numero_Vuelo()){//si el numero de vuelo coincide con el vuelo reservado
                arreglo_vuelos[i] = vuelo_seleccionado;//actualizamos los datos en el array
            }
    }

int distancia_vuelo = int (cliente_seleccionado->Get_Vuelo()->GetDistancia());

        if( cliente_seleccionado->Get_KM_Recorridos() - distancia_vuelo  > 50000){//si el cliente ha recorrido m�s de 50,000 km se aplica un descuento
    //RESTAMOS LOS KM QUE VA A RECORRER EN EL VUELO QUE ACABA DE RESERVAR, PARA ASEGURARNOS QUE HA RECORRIDO 50,000 KM SIN INCLUIR EL VUELO PROXIMO
                        cout<<endl<<"Usted es elegible para un descuento del 40% en el precio de su boleto"<<endl;
                        float precio_con_descuento = (cliente_seleccionado->Get_Precio())*(.60);//aplicamos un descuento del 40% en el precio de su boleto
                        cliente_seleccionado->Set_Precio(precio_con_descuento);
                        cout<<"A";sleep(1);cout<<"P";sleep(1);cout<<"L";sleep(1);cout<<"I";sleep(1);cout<<"C";sleep(1);cout<<"A";sleep(1);cout<<"N";sleep(1);cout<<"D";sleep(1);cout<<"O";
                        cout<<" ";sleep(1);cout<<"D";sleep(1);cout<<"E";sleep(1);cout<<"S";sleep(1);cout<<"C";sleep(1);cout<<"U";sleep(1);cout<<"E";sleep(1);cout<<"N";sleep(1);cout<<"T";sleep(1);cout<<"O"<<endl;

                        cout<<endl<<endl<<"DATOS CON PRECIO ACTUALIZADO: "<<endl<<endl;
                        cout<<"Numero De Vuelo: "<<cliente_seleccionado->Get_Numero_Vuelo()<<endl;
                        cout<<"Duracion estimada de vuelo: "<<cliente_seleccionado->GetDuracionVuelo()<<" minutos"<<endl;
                        cout<<"precio del boleto: "<<cliente_seleccionado->Get_Precio()<<"$"<<endl;
                        cout<<"kilometros acumulados finales: "<<cliente_seleccionado->Get_KM_Recorridos()<<endl;
                    }
    }

    else{
    cout<<"Usuario no existente, POR FAVOR REGISTRARSE"<<endl;
    break;
    }
}//fin de reservar vuelo para cliente
    //}//FIN del else if "vuelos encontrados == true"
    break;
    }//fin del switch case 2

case 3: //buscar vuelos por fecha
    {


    system("cls");
    cout<<endl<<"Ingresa el destino en el que desee buscar vuelos: ";
    cin>>destino;
    system("cls");

    for (int i = 0; i < 5; i++){
        if(destino==arreglo_vuelos[i].GetDestino()){//mostramos los vuelos disponibles en el destino ingresado
            arreglo_vuelos[i].MostrarVuelos();
            vuelos_encontrados = true;
        }
    }






if(vuelos_encontrados == false)//si no hay vuelos disponibles
{
    cout<<"NO HAY VUELOS DISPONIBLES PARA EL DESTINO INGRESADO"<<endl;
    break;
}



else if(vuelos_encontrados == true){
    cout<<"Ingresa el numero de vuelo que deseas: ";
    cin>>numero_vuelo;//pedimos el numero



    for (int i = 0; i < 5; i++){//verificamos que el vuelo seleccionado exista
            if(numero_vuelo == arreglo_vuelos[i].Get_Numero_Vuelo()){//si el numero de vuelo escogido si esta disponible
                vuelo_seleccionado_encontrado = true;
                vuelo_seleccionado = arreglo_vuelos[i];
                num_vuelo_valido = true;
            }
    }

    if(!num_vuelo_valido){ //si vuelo_valido == false
        cout<<"NUMERO DE VUELO INVALIDO"<<endl;
        break;
    }
    cout << "Ingresa el numero de boletos que desea reservar: ";
    cin >> numBoletos;
    system("cls");


if(vuelo_seleccionado.GetDisponibilidad()>=(int)numBoletos){//si aun hay asientos disponibles
            asiento_disponible = true;
            }


    if(!asiento_disponible){
        cout<<"EL VUELO YA NO CUENTA CON ASIENTOS DISPONIBLES"<<endl;
        break;
    }

    if(vuelo_seleccionado_encontrado && asiento_disponible){//si si existe el vuelo seleccionado
        vuelo_seleccionado.MostrarDatos();//mostramos los datos del vuelo para confirmar
        cout<<"Por favor ingresa \"S\" si confirmas tu vuelo o \"N\" si deseas regresar al menu: ";
        fflush(stdin);
        cin>>confirmar_vuelo;

                if(confirmar_vuelo =='S'){//confirmamos la reservacion del vuelo
                        reservacion_confirmada = true;
                        system("cls");
                        fflush(stdin);
                        cout<<endl<<"Usuario: ";
                        getline(cin,nombre_cliente);
                        cout<<endl<<"Password: ";
                        cin>>password;
                }//fin if de confirmar vuelo
                else{
                    break;
                }
    }
    else{
        break;
    }
}



if(reservacion_confirmada == true){//reservar vuelo para cliente

    //BUSCAMOS SI EL CLIENTE YA ESTA REGISTRADO
    for(int i =0; i<=obj_Arr_Cliente->Get_Indice();i++)//recorremos todo el arreglo de los clientes
    {
        if(nombre_cliente==obj_Arr_Cliente->Get_Cliente(i)->GetNombre() && password == obj_Arr_Cliente->Get_Cliente(i)->Get_Contrasenia() ){// si el usuario ya existe autorizamos el siguiente paso
        cliente_encontrado = true;
        indice_cliente = obj_Arr_Cliente->Get_Indice();//obtenemos el cliente
        cliente_seleccionado = obj_Arr_Cliente->Get_Cliente(i);
        }
    }

    if(cliente_encontrado == true){//realizamos la reservaci�n
        cliente_seleccionado->Reservar_Vuelo(&vuelo_seleccionado, numBoletos);
        //una vez que hemos hecho la reservacion, hay que actualizar los datos del vuelo en el array (vuelo_seleccionado ya tiene la update de las modificaciones hechas)
        for (int i = 0; i < 5; i++){//verificamos que el vuelo seleccionado exista
            if(vuelo_seleccionado.Get_Numero_Vuelo() == arreglo_vuelos[i].Get_Numero_Vuelo()){//si el numero de vuelo coincide con el vuelo reservado
                arreglo_vuelos[i] = vuelo_seleccionado;//actualizamos los datos en el array
            }
    }

int distancia_vuelo = int (cliente_seleccionado->Get_Vuelo()->GetDistancia());

        if( cliente_seleccionado->Get_KM_Recorridos() - distancia_vuelo  > 50000){//si el cliente ha recorrido m�s de 50,000 km se aplica un descuento
    //RESTAMOS LOS KM QUE VA A RECORRER EN EL VUELO QUE ACABA DE RESERVAR, PARA ASEGURARNOS QUE HA RECORRIDO 50,000 KM SIN INCLUIR EL VUELO PROXIMO
                        cout<<endl<<"Usted es elegible para un descuento del 40% en el precio de su boleto"<<endl;
                        float precio_con_descuento = (cliente_seleccionado->Get_Precio())*(.60);//aplicamos un descuento del 40% en el precio de su boleto
                        cliente_seleccionado->Set_Precio(precio_con_descuento);
                        cout<<"A";sleep(1);cout<<"P";sleep(1);cout<<"L";sleep(1);cout<<"I";sleep(1);cout<<"C";sleep(1);cout<<"A";sleep(1);cout<<"N";sleep(1);cout<<"D";sleep(1);cout<<"O";
                        cout<<" ";sleep(1);cout<<"D";sleep(1);cout<<"E";sleep(1);cout<<"S";sleep(1);cout<<"C";sleep(1);cout<<"U";sleep(1);cout<<"E";sleep(1);cout<<"N";sleep(1);cout<<"T";sleep(1);cout<<"O"<<endl;

                        cout<<endl<<endl<<"DATOS CON PRECIO ACTUALIZADO: "<<endl<<endl;
                        cout<<"Numero De Vuelo: "<<cliente_seleccionado->Get_Numero_Vuelo()<<endl;
                        cout<<"Duracion estimada de vuelo: "<<cliente_seleccionado->GetDuracionVuelo()<<" minutos"<<endl;
                        cout<<"precio del boleto: "<<cliente_seleccionado->Get_Precio()<<"$"<<endl;
                        cout<<"kilometros acumulados finales: "<<cliente_seleccionado->Get_KM_Recorridos()<<endl;
                    }
    }

    else{
    cout<<"Usuario no existente, POR FAVOR REGISTRARSE"<<endl;
    break;
    }
}//fin de reservar vuelo para cliente
    //}//FIN del else if "vuelos encontrados == true"
    break;//fin del case 3
    }



    case 4:
        {
            system("cls");
            cout<<"Mostrando clientes: "<<endl<<endl;
            for(int i =0;i<=obj_Arr_Cliente->Get_Indice();i++){
                cout<<endl<<endl<<endl;
                cout<<"Nombre: "<<obj_Arr_Cliente->Get_Cliente(i)->GetNombre()<<endl;
                cout<<"Edad: "<<obj_Arr_Cliente->Get_Cliente(i)->GetEdad()<<endl;
                cout<<"km recorridos: "<<obj_Arr_Cliente->Get_Cliente(i)->Get_KM_Recorridos()<<" km"<<endl;
                cout<<"Destino: "<<obj_Arr_Cliente->Get_Cliente(i)->Get_Destino()<<endl;//OBTENEMOS EL VUELO DEL CLIENTE Y DESPUES SU DESTINO
                cout<<"Precio boleto: "<<obj_Arr_Cliente->Get_Cliente(i)->Get_Precio()<<"$"<<endl;
                cout<<"Boletos reservados: "<<obj_Arr_Cliente->Get_Cliente(i)->GetBoletosReservados()<<endl;
            }
            break;
        }//fin del case 3

    case 5:
        {//CANCELAR RESERVACI�N

            system("cls");
            fflush(stdin);
            cout<<endl<<"Ingresa tu Usuario: ";
            getline(cin,nombre_cliente);
            cout<<endl<<"Password: ";
            cin>>password;


        //buscamos al cliente
        for(int i =0; i<=obj_Arr_Cliente->Get_Indice();i++)//recorremos todo el arreglo de los clientes
        {
            if(nombre_cliente==obj_Arr_Cliente->Get_Cliente(i)->GetNombre() && password == obj_Arr_Cliente->Get_Cliente(i)->Get_Contrasenia()){// si el usuario ya existe
            cliente_encontrado_cancelar_reservacion = true;
            cliente_seleccionado = obj_Arr_Cliente->Get_Cliente(i);
            }
        }

        if(cliente_encontrado_cancelar_reservacion == true && cliente_seleccionado->Get_Destino()!= "NO ASIGNADO"){//cancelamos la reservacion

           //cancelamos vuelo
           int boletos_reservados = cliente_seleccionado->GetBoletosReservados();
           vuelo_cancelado = cliente_seleccionado->Cancelar_Reservacion();

            //actualizamos el array de vuelos, para actualizar la disponibilidad de la reservacion cancelada
           for (int i = 0; i < 5; i++){
            if(vuelo_cancelado == arreglo_vuelos[i].Get_Numero_Vuelo()){//si el numero de vuelo coincide con el vuelo cancelado
                arreglo_vuelos[i].SetDisponibilidad(arreglo_vuelos[i].GetDisponibilidad()+boletos_reservados);
            }
           }



        }
        else if(cliente_encontrado_cancelar_reservacion == true && cliente_seleccionado->Get_Destino()== "NO ASIGNADO"){//si no tiene una reservacion hecha
            cout<<"EL CLIENTE NO CUENTA CON NINGUNA RESERVACION ACTIVA"<<endl;
        }


        else{
        cout<<"USUARIO NO ENCONTRADO"<<endl;
        break;
        }


        break;
        }//fin del case 4

    case 6:
        {
        exit(0);
        }
  default:
    cout<<"Ingresa una opcion valida"<<endl;
}//fin del switch
cout<<endl<<endl<<"Desea regresar al menu principal? (s/n): ";
cin>>repetir;
}while(repetir == 's');




return 0;
}



