//Clase vuelo
#include<string>
#include"arl.h"
#include<vector>
#include <iostream>
//#include"cliente.h"
using namespace std;
class Vuelo{
string fecha;
string numero_vuelo;
float precio;
int duracion_viaje_min; //es en minutos
int disponibilidad;
float distancia_km; //es en kilometros
string nombre_arl;
string destino;
//Aerolineas arl; //DEBE SER AL REV�S  LAS ARL DEBEN TENER VUELOS (DE ESTA MANERA SI SE BORRA LA ARL, SE BORRAN LOS VUELOS)

//vector <Clientes> *lista_espera;



public:
Vuelo(string fechap, string numero_vuelop,float preciop,int
duracion_viajep, int disponibilidadp, float distancia_kmp, Aerolineas arlp,string destinop){
  fecha = fechap;
  numero_vuelo = numero_vuelop;
  precio=preciop;
  duracion_viaje_min = duracion_viajep;
  disponibilidad = disponibilidadp;
  distancia_km = distancia_kmp;
  destino = destinop;
  nombre_arl = arlp.GetNombre();

  cout<<"Creando vuelo"<<endl;
}
Vuelo(){//constructor vacio
}
~Vuelo(){
  cout<<"Destuyendo vuelo"<<endl;
}

//vector lista_espera
/*
void SetEspera(Cliente *Cliente){
lista_espera.push_back(&cliente);
}

vector<Clientes> GetLista(){
return lista_espera;
}
*/


/*void Set_Arl_Nombre(string nombrep){
arl.SetNombre(nombrep);
}*/



//fecha
void SetFecha(string fecha_p){
fecha = fecha_p;
}
string GetFecha()
{
  return fecha;
}

//numero_vuelo
void Set_Numero_Vuelo(string numero_vuelop){
numero_vuelo = numero_vuelop;
}
string Get_Numero_Vuelo()
{
  return numero_vuelo;
}

//precio
void SetPrecio(float preciop){
precio = preciop;
}
float GetPrecio()
{
  return precio;
}


//duracion_viaje_min
void Set_Duracion_Viaje(int duracion_viajep){
duracion_viaje_min=duracion_viajep;
}
int GetDuracionVuelo()
{
  return duracion_viaje_min;
}

//disponibilidad
void SetDisponibilidad(int disponibilidadp){
disponibilidad = disponibilidadp;
}
int GetDisponibilidad()
{
  return disponibilidad;
}

//distancia
void SetDistancia(float distanciap){
distancia_km = distanciap;
}
float GetDistancia()
{
  return distancia_km;
}

//nombre_arl
void SetNombre_Arl(string nombre_arlp){
nombre_arl = nombre_arlp;
}
string GetNombreArl()
{
return nombre_arl;
}

//destino
void SetDestino(string destinop){
destino = destinop;
}
string GetDestino()
{
  return destino;
}

//otros m�todos

void MostrarDatos(){

    cout<<endl<<endl<<"Detalles del vuelo escogido: "<<endl<<endl;

    cout<<"Numero de vuelo:" <<numero_vuelo<<endl;
    cout<<"Disponibilidad:" <<disponibilidad<<endl;
    cout<<"Distancia:" <<distancia_km<<endl;
    cout<<"Duracion de vuelo: " <<duracion_viaje_min<<endl;
    cout<<"Fecha: " <<fecha<<endl;
    cout<<"Aerolinea: "<<nombre_arl<<endl;
    cout<<"Destino: "<<destino<<endl;
    cout<<"Precio: "<<"$"<<precio<<endl<<endl<<endl;
}
void MostrarVuelos(){

    cout<<endl<<endl<<"Vuelo Disponible: "<<endl<<endl;

    cout<<"Numero de vuelo:" <<numero_vuelo<<endl;
    cout<<"Disponibilidad:" <<disponibilidad<<endl;
    cout<<"Distancia:" <<distancia_km<<endl;
    cout<<"Duracion de vuelo: " <<duracion_viaje_min<<endl;
    cout<<"Fecha: " <<fecha<<endl;
    cout<<"Aerolinea: "<<nombre_arl<<endl;
    cout<<"Destino: "<<destino<<endl;
    cout<<"Precio: "<<"$"<<precio<<endl<<endl<<endl;
}

};
